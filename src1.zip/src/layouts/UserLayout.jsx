import React from 'react';
import { Container, Box } from '@mui/material';
import Header from '../components/Header';

const UserLayout = ({ children }) => {
  return (
    <>
      <Header />
      <Box mt={4}>
        <Container>{children}</Container>
      </Box>
    </>
  );
};

export default UserLayout;
