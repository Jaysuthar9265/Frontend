// src/components/Login.jsx

import React, { useState, useContext } from 'react';
import { Container, TextField, Button, Typography, Box } from '@mui/material';
import API from '../services/api';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/UserContext.jsx';


const Login = () => {
  const [form, setForm] = useState({ email: '', password: '' });
  const navigate = useNavigate();
  const { login } = useContext(UserContext);  // Fix: use login from context instead of setUser directly

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      const res = await API.post('/auth/login', form);

      // Save user in context and localStorage
      const userData = {
        name: res.data.user.name,
        role: res.data.user.role,
        token: res.data.token,
      };
      
      login(userData); // Use the login function from context to set user

      alert('Login Successful ✅');

      // Redirect
      if (res.data.role === 'admin') navigate('/admin/dashboard');
      else if (res.data.role === 'client') navigate('/');
      else if (res.data.role === 'chef') navigate('/chef/dashboard');
      else if (res.data.role === 'vendor') navigate('/vendor/dashboard');
      else navigate('/');

    } catch (err) {
      alert(err.response?.data?.message || 'Login failed');
    }
  };

  return (
    <Container maxWidth="xs">
      <Box mt={5}>
        <Typography variant="h5">Login</Typography>
        <TextField fullWidth margin="normal" name="email" label="Email" onChange={handleChange} />
        <TextField fullWidth margin="normal" name="password" label="Password" type="password" onChange={handleChange} />
        <Button fullWidth variant="contained" onClick={handleSubmit}>Login</Button>
      </Box>
    </Container>
  );
};

export default Login;
