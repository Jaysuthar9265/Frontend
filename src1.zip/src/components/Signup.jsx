import React, { useState } from 'react';
import {
  Container, TextField, Button, MenuItem, Typography, Box
} from '@mui/material';
import API from '../services/api';

const roles = ['admin', 'client', 'chef', 'vendor'];

const Signup = () => {
  const [form, setForm] = useState({
    name: '', email: '', password: '', role: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      const res = await API.post('/auth/signup', form);
      alert(res.data.message);
    } catch (err) {
      alert(err.response?.data?.message || 'Signup failed');
    }
  };

  return (
    <Container maxWidth="xs">
      <Box mt={5}>
        <Typography variant="h5">Sign Up</Typography>
        <TextField fullWidth margin="normal" name="name" label="Name" onChange={handleChange} />
        <TextField fullWidth margin="normal" name="email" label="Email" onChange={handleChange} />
        <TextField fullWidth margin="normal" name="password" label="Password" type="password" onChange={handleChange} />
        <TextField fullWidth select margin="normal" name="role" label="Role" onChange={handleChange}>
          {roles.map(role => <MenuItem key={role} value={role}>{role}</MenuItem>)}
        </TextField>
        <Button fullWidth variant="contained" onClick={handleSubmit}>Sign Up</Button>
      </Box>
    </Container>
  );
};

export default Signup;
