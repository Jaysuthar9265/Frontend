import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import UserLayout from './layouts/UserLayout';
import RecipesPage from './pages/RecipesPage';
import Login from './components/Login';
import Signup from './components/Signup';

const App = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />

      {/* Protected User Routes */}
      <Route
        path="/"
        element={
          <UserLayout>
            <HomePage />
          </UserLayout>
        }
      />
      <Route
        path="/recipes"
        element={
          <UserLayout>
            <RecipesPage />
          </UserLayout>
        }
      />
    </Routes>
  );
};

export default App;
