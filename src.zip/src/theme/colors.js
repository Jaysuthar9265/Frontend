export const navbarColor = '#1e88e5';
