import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import RecipesPage from './pages/RecipesPage';
import Login from './components/Login';
import Signup from './components/Signup';
import UserLayout from './layouts/UserLayout';
import PrivateRoute from './components/PrivateRoute';
// Dashboards

import ClientDashboard from './pages/client/ClientDashboard';
import ChefDashboard from './pages/chef/ChefDashboard';
import VendorDashboard from './pages/vendor/VendorDashboard';
//Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminUsers from './pages/admin/AdminUsers';
import AddAdmin from './pages/admin/AddAdmin';

const App = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />

      {/* Default User Pages */}
      <Route
        path="/"
        element={
          <UserLayout>
            <HomePage />
          </UserLayout>
        }
      />
      <Route
        path="/recipes"
        element={
          <UserLayout>
            <RecipesPage />
          </UserLayout>
        }
      />

      {/* Role-Based Dashboards */}
      <Route
    path="/admin/dashboard"
    element={
      <PrivateRoute allowedRoles={['admin']}>
        <UserLayout>
        <AdminDashboard />
        </UserLayout>
      </PrivateRoute>
    }
  />
  <Route path="/admin/users" element={<PrivateRoute  allowedRoles={['admin']}><UserLayout><AdminUsers /></UserLayout></PrivateRoute>} />
  <Route path="/admin/add-admin" element={<PrivateRoute  allowedRoles={['admin']}><UserLayout><AddAdmin /></UserLayout></PrivateRoute>} />
  <Route
    path="/client/dashboard"
    element={
      <PrivateRoute allowedRoles={['client']}>
        <UserLayout>
        <ClientDashboard />
        </UserLayout>
      </PrivateRoute>
    }
  />
  <Route
    path="/chef/dashboard"
    element={
      <PrivateRoute allowedRoles={['chef']}>
        <UserLayout>
        <ChefDashboard />
        </UserLayout>
      </PrivateRoute>
    }
  />
  <Route
    path="/vendor/dashboard"
    element={
      <PrivateRoute allowedRoles={['vendor']}>
        <UserLayout>
        <VendorDashboard />
        </UserLayout>
      </PrivateRoute>
    }
  />   </Routes>
  );
};

export default App;
