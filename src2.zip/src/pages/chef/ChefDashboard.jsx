import React from 'react';

const ChefDashboard = () => {
  const name = localStorage.getItem('name');

  return (
    <div>
      <h2>Welcome Chef, {name}</h2>
      {/* Chef-specific content here */}
    </div>
  );
};

export default ChefDashboard;
